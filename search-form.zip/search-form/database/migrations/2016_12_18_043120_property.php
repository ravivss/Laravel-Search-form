<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Property extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
           Schema::create('property', function (Blueprint $table) {
            $table->increments('id');
            $table->string('Name')->unique();
			$table->integer('Price');
			$table->integer('Bedrooms');
			$table->integer('Bathrooms');
			$table->integer('Storeys');
			$table->integer('Garages');
            $table->timestamps();
        });
    }
    

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('property');
    }
}
