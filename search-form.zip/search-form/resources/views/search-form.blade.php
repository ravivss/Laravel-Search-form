<!DOCTYPE html>
<html>
	<head>
		<title>Property Search
</title>
		<link href="{{ URL::asset('asset/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" >
		<link href="{{ URL::asset('asset/css/style.css') }}" rel="stylesheet" type="text/css" >
		<link href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" >
		<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
        <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
        <script src="{{ URL::asset('asset/js/search-form.js') }}"></script>
       

	</head>
	<body>
		    <nav class="navbar navbar-dark navbar-fixed-top bg-inverse">
      <button type="button" class="navbar-toggler hidden-sm-up" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar" aria-label="Toggle navigation"></button>
      <a class="navbar-brand" href="#">Property Search</a>
      <div id="navbar">
     
      </div>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
       {{ Form::open(array('url' => 'admin/skill', 'id' => 'validate')) }}
       
      <div class="form-group">
		{!! Form::label('name', 'Name :',array('class' => '')) !!}
		{!! Form::text('name', null, ['class'=>'form-control required', 'placeholder'=>'Enter Property Name','id'=>'pname']) !!}
			<input type="hidden" id="csrf_token"  value="<?php echo $csrf_token;?>" >
     </div>
       <div class="form-group">
       	{!! Form::label('Price', 'Price :',array('class' => '')) !!}
     {!! Form::text('start_price', null, ['class'=>'form-control start_price', 'placeholder'=>'Start Price','id'=>'start_price']) !!}
     <br />
       {!! Form::text('end_price', null, ['class'=>'form-control end_price', 'placeholder'=>'End Price','id'=>'end_price']) !!}
          </div>
       
      <div class="form-group">
     {!! Form::label('Bedrooms', 'Bedrooms :',array('class' => '')) !!}
     {{ Form::select('bedrooms', [''=>'Select Bedrooms','1' => '1','2' => '2','3' => '3', '4' => '4', '5' => '5'],null,['id'=>'bedrooms','class'=>'form-control ']) }}
	 </div>
	 <div class="form-group">
     {!! Form::label('Bathrooms', 'Bathrooms :',array('class' => '')) !!}
     {{ Form::select('bathrooms', [''=>'Select Bathrooms','1' => '1','2' => '2','3' => '3', '4' => '4', '5' => '5'],null,['id'=>'bathrooms','class'=>'form-control ']) }}
	 </div>
	 <div class="form-group">
     {!! Form::label('Storeys', 'Storeys :',array('class' => '')) !!}
     {{ Form::select('storeys', [''=>'Select Storeys','1' => '1','2' => '2','3' => '3', '4' => '4', '5' => '5'],null,['id'=>'storeys','class'=>'form-control ']) }}
	 </div>
	 <div class="form-group">
     {!! Form::label('Garages', 'Garages :',array('class' => '')) !!}
     {{ Form::select('garages', [''=>'Select Garages','1' => '1','2' => '2','3' => '3', '4' => '4', '5' => '5'],null,['id'=>'garages','class'=>'form-control ']) }}
	 </div>
	 	 <div class="form-group">
   
   (*Field On change search)
	 </div>
       {!! Form::close() !!}
        </div>
        <div class="col-sm-9 offset-sm-3 col-md-10 offset-md-2 main">
          <h1>Property List</h1>

          <div class="table-responsive">
          	    <div class="loader"></div>
          	
            <table class="table table-striped list-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Price</th>
                  <th>Bedrooms</th>
                  <th>Bathrooms</th>
                  <th>Storeys</th>
                  <th>Garages</th>
                </tr>
              </thead>
              <tbody>
              	<?php foreach($property as $res) { ?>
                <tr>
                  <td><?php echo $res->Name;?></td>
                  <td><?php echo $res->Price;?></td>
                  <td><?php echo $res->Bedrooms;?></td>
                  <td><?php echo $res->Bathrooms;?></td>
                  <td><?php echo $res->Storeys;?></td>
                  <td><?php echo $res->Garages;?></td>
                </tr>
                <?php  } ?>
               
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
      <script src="{{ URL::asset('asset/js/search-form.js') }}"></script>
	</body>
</html>
