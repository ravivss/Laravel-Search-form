<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Propertysearch extends Model
{
 protected $table = 'property';
 public $timestamps = false;
 protected $fillable = [
       'id',
       'Name',
       'Bedrooms',
       'Bathrooms',
       'Storeys',
       'Garages'
        
    ];
}
