<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Propertysearch;
use DB;

class PropertyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    	$data['property'] = Propertysearch::get();
		$data['csrf_token']=csrf_token();
        return View('search-form',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
 }
      
	  
	  
	      /**
     * search result from ajax
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
			public function ajax_get_propert_result()
			{
			$request = $_POST;
			$name = $request['pname'];
			$start_price = $request['start_price'];
			$end_price = $request['end_price'];
			$bedrooms = $request['bedrooms'];
			$bathrooms = $request['bathrooms'];
			$storeys = $request['storeys'];
			$garages = $request['garages'];

			$property =  DB::table('property');
			if($name != '') {
			$property->Where('name', 'like', '%' . $name . '%');
			}
			if($start_price != '' && $end_price != '') {
			$property->whereBetween('price', [$start_price, $end_price]);
			}
			if($bedrooms != '') {
			$property->Where('bedrooms', $bedrooms);
			}
			if($bathrooms != '') {
			$property->Where('bathrooms', $bathrooms);
			}
			if($storeys != '') {
			$property->Where('storeys', $storeys);
			}
			if($garages != '') {
			$property->Where('garages', $garages);
			}
			$query = $property->get();

			$data = array();
			if ($query) {
			foreach ($query as $row) {
			$data[] = $row;

			}
			}
			echo json_encode($data);
			exit;
			}

	}
		