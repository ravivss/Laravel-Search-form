  /* auto complate script start */
  $( function() {
    var availableTags = [
      "The Victoria",
      "The Xavier",
      "The Como",
      "The Aspen",
      "The Lucretia",
      "The Toorak",
      "The Skyscape",
      "The Clifton",
      "The Geneva",
    ];
    $( "#pname" ).autocomplete({
      source: availableTags,
      select: function() {
      	setTimeout(function(){
                search_data();
         	},150);
      }
    });
  } );
  
    /* auto complate script end */

  
/* select field  change function start */
$( "#bedrooms,#bathrooms,#storeys,#garages" ).change(function() {
  search_data();
});
/* select field  change function start */


/* Input field  keyup function start */
$( "#start_price,#end_price,#storeys,#garages" ).keyup(function() {
  search_data();
});
/* Input field  keyup function end */
    
	/* Search function start */
  function search_data()
  {
         var pname=$('#pname').val();
         var end_price=$('#end_price').val();
         var start_price=$('#start_price').val();
         var bedrooms=$('#bedrooms').val();
         var bathrooms=$('#bathrooms').val();
         var storeys=$('#storeys').val();
         var garages=$('#garages').val();
        var csrf = $("#csrf_token").val();
        
       	var ajaxurl = 'property-search/ajax_get_propert_result';
	    $.ajax({
			headers: { 'X-CSRF-Token' : csrf },
			type: "post",
			url: ajaxurl,		
			data: {pname:pname,bedrooms:bedrooms,bathrooms:bathrooms,storeys:storeys,garages:garages,start_price:start_price,end_price:end_price},	
		     dataType: 'json',	
		     cache: false,
		     	beforeSend : function(){
				      	$(".loader").show();

				},
				success: function (result) {
									$(".loader").hide();
									
                   var content='';
                   if(result!='')
                   {
					$.each(result, function(result, obj) {
						content+='<tr>';
						content+='<td>'+obj.Name+'</td>';
						content+='<td>'+obj.Price+'</td>';
						content+='<td>'+obj.Bedrooms+'</td>';
						content+='<td>'+obj.Bathrooms+'</td>';
						content+='<td>'+obj.Storeys+'</td>';
						content+='<td>'+obj.Garages+'</td>';
						content+='</tr>';
						
					});
					}else{
						content+='<tr>';
						content+='<td colspan="6" class="algmt"> <strong>No match record found.</strong></td>';
						content+='</tr>';
					}
								
					$('tbody').html(content);
				
			}
		});
        
  }
  
  /* Search function end */